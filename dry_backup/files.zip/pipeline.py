"""
pipeline.py
────────────
Orchestrates all modules into one inference call.

Loads:
  - OBB/standard YOLO component model
  - Your existing shed-count model
  - Optional: lightweight insulator crop classifier

On each image:
  1. Run component YOLO → detect insulators, poles, crossarms, conductors
  2. For each insulator:
       a. Aspect ratio heuristic (fast)
       b. Crop classifier if uncertain
       c. Shed count model (your model) on confirmed pin insulators
  3. Classify crossarm shapes (straight / V / T)
  4. Classify pole orientation (vertical / strut)
  5. Detect HT+LT combined
  6. Rule engine → final pole class

Usage:
  pipeline = InfrastructurePipeline("component.pt", "shed.pt")
  result   = pipeline.predict("field_photo.jpg")
  print(result.final_class, result.reason)
"""

import cv2
import math
import numpy as np
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field
from collections import defaultdict, Counter

from ultralytics import YOLO

from config import (
    DETECTION_CONF, DETECTION_IOU, HT_LT_HEIGHT_THRESHOLD,
    OBB_CLASS_KEYWORDS, POLE_CLASSES
)
from insulator_classifier import InsulatorClassifier, InsulatorResult
from crossarm_classifier  import (
    classify_pole_orientation, classify_crossarm_shape,
    aggregate_crossarm_results, PoleOrientationResult, CrossarmResult
)
from rule_engine import classify_pole, ComponentSignals, ClassificationResult


# ── Pipeline output ───────────────────────────────────────────

@dataclass
class PipelineResult:
    """Complete output of one inference run."""
    final_class:      str
    class_id:         int
    reason:           str
    voltage:          str
    confidence:       str
    signals_used:     list

    insulators:       list  = field(default_factory=list)
    pole_orientation: Optional[PoleOrientationResult] = None
    crossarms:        list  = field(default_factory=list)
    crossarm_shape:   str   = "none"
    crossarm_count:   int   = 0
    conductor_count:  int   = 0
    flags:            dict  = field(default_factory=dict)

    # Adjustment fault summary
    adjustment_faults: list = field(default_factory=list)
    # Each entry: {"component": str, "severity": str, "note": str}


# ── Helper: keyword matcher ───────────────────────────────────

def _match_keyword(cls_name: str, category: str) -> bool:
    """
    Checks if a detected class name belongs to a category.
    Uses OBB_CLASS_KEYWORDS from config.
    """
    name_lower = cls_name.lower()
    return any(kw in name_lower for kw in OBB_CLASS_KEYWORDS.get(category, []))


# ── Main pipeline ─────────────────────────────────────────────

class InfrastructurePipeline:
    """
    Full 33kV infrastructure inspection pipeline.
    Combine component detection + angle classification + rule engine.
    """

    def __init__(
        self,
        component_model_path: str,
        shed_model_path: str,
        crop_classifier_path: Optional[str] = None,
        conf: float = DETECTION_CONF,
        iou:  float = DETECTION_IOU,
    ):
        """
        Args:
            component_model_path : path to your trained component YOLO (.pt)
            shed_model_path      : path to your shed-count model (.pt)
            crop_classifier_path : path to optional insulator crop classifier (.pt)
            conf                 : detection confidence threshold
            iou                  : NMS IoU threshold
        """
        print("Loading component model...")
        self.component_model = YOLO(component_model_path)
        self.is_obb = "obb" in component_model_path.lower()

        print("Loading insulator classifier (shed model + crop classifier)...")
        self.insulator_clf = InsulatorClassifier(
            shed_model_path      = shed_model_path,
            crop_classifier_path = crop_classifier_path,
        )

        self.conf = conf
        self.iou  = iou
        print("Pipeline ready.\n")

    def predict(
        self,
        image_path: str,
        visualize: bool = True,
        save_path: Optional[str] = None,
    ) -> PipelineResult:
        """
        Runs full pipeline on one image.

        Args:
            image_path : path to input image
            visualize  : draw and save annotated output image
            save_path  : where to save visualization (None = auto)

        Returns:
            PipelineResult with final classification + all details
        """
        img = cv2.imread(image_path)
        if img is None:
            raise FileNotFoundError(f"Cannot read image: {image_path}")

        img_h, img_w = img.shape[:2]

        # ── Run component model ───────────────────────────────
        raw = self.component_model(
            image_path, conf=self.conf, iou=self.iou, verbose=False
        )

        # ── Parse detections into typed lists ─────────────────
        insulator_boxes  = []   # (box, conf, angle_deg)
        pole_boxes_raw   = []   # (box, conf, angle_deg)
        crossarm_boxes   = []   # (box, conf)
        conductor_boxes  = []   # (box, conf)
        flags = defaultdict(bool)

        for result in raw:
            # Support both OBB and standard boxes
            obb   = result.obb   if hasattr(result, "obb")   and result.obb else None
            boxes = result.boxes if hasattr(result, "boxes") and result.boxes else None

            if obb is not None and len(obb) > 0:
                for i in range(len(obb)):
                    cls_name  = self.component_model.names[int(obb.cls[i])]
                    conf_val  = float(obb.conf[i])

                    # Get OBB parameters
                    if hasattr(obb, "xywhr") and obb.xywhr is not None:
                        xywhr = obb.xywhr[i].cpu().numpy()
                        cx, cy, bw, bh, angle_rad = xywhr
                        angle_deg = math.degrees(float(angle_rad))
                    else:
                        b = obb.xyxy[i].cpu().numpy() if hasattr(obb, "xyxy") else None
                        if b is None:
                            continue
                        cx = (b[0] + b[2]) / 2
                        cy = (b[1] + b[3]) / 2
                        bw = b[2] - b[0]
                        bh = b[3] - b[1]
                        angle_deg = 90.0

                    box = (
                        int(max(0, cx - bw/2)), int(max(0, cy - bh/2)),
                        int(min(img_w, cx + bw/2)), int(min(img_h, cy + bh/2))
                    )

                    self._categorise(
                        cls_name, box, conf_val, angle_deg,
                        insulator_boxes, pole_boxes_raw,
                        crossarm_boxes, conductor_boxes, flags
                    )

            elif boxes is not None and len(boxes) > 0:
                for box_obj in boxes:
                    cls_name = self.component_model.names[int(box_obj.cls)]
                    conf_val = float(box_obj.conf)
                    b        = box_obj.xyxy[0].cpu().numpy()
                    box      = (int(b[0]), int(b[1]), int(b[2]), int(b[3]))
                    bw = b[2] - b[0]
                    bh = b[3] - b[1]
                    # Derive angle from aspect ratio as fallback
                    angle_deg = 90.0 if bh > bw else 0.0

                    self._categorise(
                        cls_name, box, conf_val, angle_deg,
                        insulator_boxes, pole_boxes_raw,
                        crossarm_boxes, conductor_boxes, flags
                    )

        # ── Classify each insulator ───────────────────────────
        insulator_results = []
        for box, conf_val, angle_deg in insulator_boxes:
            ins_result = self.insulator_clf.classify(
                img, box, conf_val, obb_angle_deg=angle_deg
            )
            insulator_results.append(ins_result)

        # ── Classify pole orientation ─────────────────────────
        pole_result = None
        if pole_boxes_raw:
            # Use the most prominent pole (largest bbox area)
            pole_boxes_raw.sort(key=lambda x: (x[0][2]-x[0][0])*(x[0][3]-x[0][1]),
                                 reverse=True)
            main_box, _, main_angle = pole_boxes_raw[0]
            pole_result = classify_pole_orientation(main_box, main_angle)

        # ── Classify crossarm shapes ──────────────────────────
        crossarm_results = []
        for cb, ca in crossarm_boxes:
            cr = classify_crossarm_shape(
                cb,
                [c for c, _ in conductor_boxes],
                [p for p, _, _ in pole_boxes_raw],
                img.shape,
                obb_angle_deg=ca,
            )
            crossarm_results.append(cr)

        dominant_shape, n_crossarms, crossarm_faults = aggregate_crossarm_results(crossarm_results)

        # ── Collect all adjustment faults ─────────────────────
        adjustment_faults = []

        for ins in insulator_results:
            if ins.adjustment_fault:
                adjustment_faults.append({
                    "component": f"insulator ({ins.type_final})",
                    "severity":  ins.fault_severity,
                    "note":      ins.fault_note,
                })

        if pole_result and pole_result.adjustment_fault:
            adjustment_faults.append({
                "component": "pole",
                "severity":  pole_result.fault_severity,
                "note":      pole_result.fault_note,
            })

        for cr in crossarm_faults:
            adjustment_faults.append({
                "component": f"crossarm ({cr.shape})",
                "severity":  cr.fault_severity,
                "note":      cr.fault_note,
            })

        # ── Detect HT + LT on same pole ──────────────────────
        if conductor_boxes:
            y_centres = [(b[1] + b[3]) / 2 for b, _ in conductor_boxes]
            if len(y_centres) >= 2:
                y_range = max(y_centres) - min(y_centres)
                if y_range > img_h * HT_LT_HEIGHT_THRESHOLD:
                    flags["has_ht_and_lt"] = True

        # ── Build ComponentSignals ────────────────────────────
        # Use dominant insulator if multiple detected
        best_ins = self._dominant_insulator(insulator_results)

        signals = ComponentSignals(
            insulator_type    = best_ins.type_final      if best_ins else "unknown",
            insulator_voltage = best_ins.voltage         if best_ins else "unknown",
            shed_count        = best_ins.shed_count      if best_ins else 0,
            insulator_conf    = best_ins.type_confidence if best_ins else "low",

            has_dtr      = flags["has_dtr"],
            has_lamp     = flags["has_lamp"],
            has_ab_cable = flags["has_ab_cable"],
            has_lattice  = flags["has_lattice"],
            has_jumper   = flags["has_jumper"],
            has_ht_and_lt= flags["has_ht_and_lt"],

            pole_type      = pole_result.pole_type      if pole_result else "vertical_pole",
            lean_angle_deg = pole_result.lean_angle_deg if pole_result else 0.0,

            crossarm_count  = n_crossarms,
            crossarm_shape  = dominant_shape,
            conductor_count = len(conductor_boxes),
        )

        # ── Rule engine → final class ─────────────────────────
        classification = classify_pole(signals)

        # ── Build result ──────────────────────────────────────
        pipeline_result = PipelineResult(
            final_class      = classification.final_class,
            class_id         = classification.class_id,
            reason           = classification.reason,
            voltage          = classification.voltage,
            confidence       = classification.confidence,
            signals_used     = classification.signals_used,
            insulators       = insulator_results,
            pole_orientation = pole_result,
            crossarms        = crossarm_results,
            crossarm_shape   = dominant_shape,
            crossarm_count   = n_crossarms,
            conductor_count  = len(conductor_boxes),
            flags            = dict(flags),
            adjustment_faults= adjustment_faults,
        )

        # ── Visualize ─────────────────────────────────────────
        if visualize:
            vis = self._draw(img, pipeline_result, raw)
            out = save_path or (Path(image_path).stem + "_result.jpg")
            cv2.imwrite(str(out), vis)
            print(f"Saved: {out}")

        return pipeline_result

    # ── Internal helpers ──────────────────────────────────────

    def _categorise(
        self, cls_name, box, conf_val, angle_deg,
        insulator_boxes, pole_boxes_raw,
        crossarm_boxes, conductor_boxes, flags
    ):
        """Routes a detection into the right typed list."""
        if _match_keyword(cls_name, "insulator"):
            insulator_boxes.append((box, conf_val, angle_deg))
        elif _match_keyword(cls_name, "pole"):
            pole_boxes_raw.append((box, conf_val, angle_deg))
        elif _match_keyword(cls_name, "crossarm"):
            crossarm_boxes.append((box, conf_val))
        elif _match_keyword(cls_name, "conductor"):
            conductor_boxes.append((box, conf_val))
        elif _match_keyword(cls_name, "dtr_tank"):
            flags["has_dtr"] = True
        elif _match_keyword(cls_name, "lamp_head"):
            flags["has_lamp"] = True
        elif _match_keyword(cls_name, "ab_cable"):
            flags["has_ab_cable"] = True
        elif _match_keyword(cls_name, "lattice_frame"):
            flags["has_lattice"] = True
        elif _match_keyword(cls_name, "jumper_wire"):
            flags["has_jumper"] = True

    def _dominant_insulator(
        self,
        results: list,
    ) -> Optional[InsulatorResult]:
        """
        Returns the most reliable insulator result.
        Prefers high-confidence classifications and pin insulators
        (more common in Indian distribution networks).
        """
        if not results:
            return None

        # Prefer high confidence
        high_conf = [r for r in results if r.type_confidence == "high"]
        if high_conf:
            # Among high-confidence, prefer pin (we have shed count for it)
            pins = [r for r in high_conf if r.type_final == "pin"]
            return pins[0] if pins else high_conf[0]

        # Fall back to any result
        pins = [r for r in results if r.type_final == "pin"]
        return pins[0] if pins else results[0]

    def _draw(
        self,
        img: np.ndarray,
        result: PipelineResult,
        raw_detections,
    ) -> np.ndarray:
        """Draws detections + classification banner on image."""
        vis   = img.copy()
        img_h, img_w = img.shape[:2]

        # Draw raw detections
        for r in raw_detections:
            if r.boxes is not None:
                for box in r.boxes:
                    b = box.xyxy[0].cpu().numpy().astype(int)
                    cv2.rectangle(vis, (b[0], b[1]), (b[2], b[3]), (180, 180, 180), 1)

        # Highlight insulator detections with type + shed count
        for ins in result.insulators:
            x1, y1, x2, y2 = ins.box
            color = (50, 200, 50) if ins.type_final == "pin" else (50, 50, 220)
            cv2.rectangle(vis, (x1, y1), (x2, y2), color, 3)
            label = (
                f"{ins.type_final} | "
                f"sheds={ins.shed_count} | "
                f"{ins.voltage} | "
                f"AR={ins.aspect_ratio} | "
                f"conf={ins.type_confidence}"
            )
            cv2.putText(vis, label, (x1, max(12, y1 - 6)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.48, color, 2)

        # Pole orientation
        if result.pole_orientation:
            po = result.pole_orientation
            x1, y1, x2, y2 = po.box
            cv2.rectangle(vis, (x1, y1), (x2, y2), (220, 180, 50), 2)
            cv2.putText(vis, po.pole_type,
                        (x1, y2 + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 180, 50), 2)

        # Final class banner
        banner_h = 70
        banner = np.zeros((banner_h, img_w, 3), dtype=np.uint8)
        banner[:] = (25, 25, 25)
        conf_color = {
            "high": (50, 220, 50), "medium": (50, 180, 220), "low": (80, 80, 220)
        }.get(result.confidence, (150, 150, 150))

        cv2.putText(banner, f"CLASS: {result.final_class}",
                    (10, 26), cv2.FONT_HERSHEY_DUPLEX, 0.85, conf_color, 2)
        cv2.putText(banner, f"Reason: {result.reason}",
                    (10, 46), cv2.FONT_HERSHEY_SIMPLEX, 0.46, (170, 170, 170), 1)
        cv2.putText(banner,
                    f"voltage={result.voltage} | "
                    f"crossarm={result.crossarm_shape}({result.crossarm_count}) | "
                    f"conf={result.confidence}",
                    (10, 64), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (120, 120, 120), 1)

        return np.vstack([banner, vis])


# ── CLI ───────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 4:
        print("Usage: python pipeline.py IMAGE COMPONENT_MODEL SHED_MODEL [CROP_CLASSIFIER]")
        sys.exit(1)

    img_path   = sys.argv[1]
    comp_path  = sys.argv[2]
    shed_path  = sys.argv[3]
    crop_path  = sys.argv[4] if len(sys.argv) > 4 else None

    pipeline = InfrastructurePipeline(comp_path, shed_path, crop_path)
    result   = pipeline.predict(img_path, visualize=True)

    print("\n" + "=" * 55)
    print(f"FINAL CLASS  : {result.final_class}")
    print(f"REASON       : {result.reason}")
    print(f"VOLTAGE      : {result.voltage}")
    print(f"CONFIDENCE   : {result.confidence}")
    print(f"CROSSARM     : {result.crossarm_count}x {result.crossarm_shape}")
    print(f"CONDUCTORS   : {result.conductor_count}")
    print(f"FLAGS        : {result.flags}")
    print(f"SIGNALS USED : {result.signals_used}")
    if result.adjustment_faults:
        print(f"\nADJUSTMENT FAULTS ({len(result.adjustment_faults)}):")
        for f in result.adjustment_faults:
            icon = "🔴" if f["severity"] == "fault" else "🟡"
            print(f"  {icon} [{f['severity'].upper()}] {f['component']}: {f['note']}")
    else:
        print("\nADJUSTMENT FAULTS: none detected")
    if result.insulators:
        print("\nINSULATOR DETAILS:")
        for i, ins in enumerate(result.insulators):
            print(f"  [{i}] type={ins.type_final}"
                  f"  heuristic={ins.type_heuristic}"
                  f"  sheds={ins.shed_count}"
                  f"  voltage={ins.voltage}"
                  f"  AR={ins.aspect_ratio}"
                  f"  conf={ins.type_confidence}")
    if result.pole_orientation:
        po = result.pole_orientation
        print(f"\nPOLE: {po.pole_type}  lean={po.lean_angle_deg}°  {po.note}")
    print("=" * 55)
