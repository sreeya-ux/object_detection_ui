"""
config.py
─────────
Single source of truth for all thresholds, class names,
and dataset references.

CHANGE LOG:
  - Removed insulator fault detection datasets (broken disc, cracked cap)
  - Added adjustment fault thresholds (tilt, skew, misalignment)
  - Fault detection = geometric misalignment only, not physical damage
"""

# ── Insulator aspect-ratio thresholds ───────────────────────
INSULATOR_PIN_RATIO_MIN   = 1.5   # height/width > this  → likely pin
INSULATOR_DISC_RATIO_MAX  = 0.7   # height/width < this  → likely disc

# ── Adjustment fault thresholds ──────────────────────────────
# "Adjustment fault" = component is physically present but
#  misaligned, tilted, or improperly seated — not physically broken.
#
# Detected purely from bounding box geometry and OBB angle.
# No separate fault detection model needed.

# Pin insulator tilt
# Correctly mounted pin insulator points straight up (OBB angle ≈ 90°)
PIN_INSULATOR_IDEAL_ANGLE   = 90.0   # degrees
PIN_INSULATOR_TOLERANCE_DEG = 15.0   # ±15° → ok
PIN_INSULATOR_FAULT_DEG     = 25.0   # beyond ±25° → adjustment fault

# Pin insulator aspect ratio when tilted
# A tilted pin insulator has a wider bbox → lower height/width ratio
PIN_TILT_AR_THRESHOLD       = 1.2    # if ratio < 1.2 for a "pin" → may be tilted

# Crossarm level check
# A correctly mounted crossarm is horizontal (OBB angle ≈ 0°)
CROSSARM_IDEAL_ANGLE_DEG    = 0.0
CROSSARM_TOLERANCE_DEG      = 8.0    # ±8° → ok
CROSSARM_FAULT_DEG          = 15.0   # beyond ±15° → adjustment fault

# Pole lean
# Vertical pole has OBB angle ≈ 90°
POLE_IDEAL_ANGLE_DEG        = 90.0
POLE_TOLERANCE_DEG          = 5.0    # ±5° → ok
POLE_FAULT_DEG              = 10.0   # beyond ±10° → adjustment fault
# Note: strut poles lean intentionally — skip fault check if pole_type=strut
POLE_STRUT_THRESHOLD_DEG    = 30.0   # lean > 30° → definitely strut, not fault

# ── Shed count → voltage (Indian standard) ───────────────────
SHED_VOLTAGE_MAP = {
    0: "LT",
    1: "6.3kV",
    2: "6.3kV",
    3: "11kV",
}
SHED_VOLTAGE_GT3 = "33kV"

# ── Crossarm shape thresholds ────────────────────────────────
CROSSARM_MIN_AR_STRAIGHT    = 4.0
CROSSARM_CONDUCTOR_V_SPREAD = 0.8
CROSSARM_T_VERTICAL_RATIO   = 0.05

# ── HT+LT separation ─────────────────────────────────────────
HT_LT_HEIGHT_THRESHOLD = 0.25

# ── Detection thresholds ─────────────────────────────────────
DETECTION_CONF  = 0.25
DETECTION_IOU   = 0.45
SHED_MODEL_CONF = 0.20

# ── Augmentation ─────────────────────────────────────────────
AUG_TARGET_COUNT    = 200
AUG_SILHOUETTE_PROB = 0.20

# ── OBB component class keywords ─────────────────────────────
OBB_CLASS_KEYWORDS = {
    "insulator":    ["insulator"],
    "pole":         ["pole"],
    "crossarm":     ["crossarm", "cross_arm", "cross arm"],
    "conductor":    ["conductor", "wire", "cable", "power_line"],
    "dtr_tank":     ["transformer", "dtr", "distribution transformer"],
    "lamp_head":    ["lamp", "street light", "streetlight", "stl"],
    "ab_cable":     ["ab_cable", "bundled", "aerial bundle"],
    "lattice_frame":["lattice", "tower", "m9", "m+9"],
    "jumper_wire":  ["jumper", "tapping"],
}

# ── Final 15 pole classes ─────────────────────────────────────
POLE_CLASSES = [
    "33kV_pole",         # 0
    "33kV_HT_pole",      # 1
    "11kV_HT_pole",      # 2
    "6.3kV_pole",        # 3
    "6.3kV_HT_pole",     # 4
    "HT_pole",           # 5
    "LT_pole",           # 6
    "HT_LT_pole",        # 7
    "DTR_HT_pole",       # 8
    "DTR_and_pole",      # 9
    "LT_AB_cable_pole",  # 10
    "LT_pole_plain",     # 11
    "street_light_pole", # 12
    "HT_tapping_point",  # 13
    "M9_tower",          # 14
]

# ── Datasets (fault datasets removed) ────────────────────────
# REMOVED: insulator_faults, insulator_fault2, porcelain_insulators
# Reason: we only detect adjustment/alignment faults via geometry,
#         not physical damage — no fault image dataset needed.
DATASETS = [
    ("akshay-anand-bfabb", "pole-data",          1, "pole_data"),
    ("zac-ogogt",          "utility-poles-kcumt", 1, "utility_poles"),
    ("hanshin-university", "all_image",           1, "all_image"),
    ("indian-institute-of-technology-jodhpour",
     "cable-detection-liolt", 1,                     "cable_detection"),
]

TTPLA_GITHUB = "https://github.com/R3ab/ttpla_dataset"

DS_CLASS_MAPS = {
    "pole_data": {
        "pole": 5, "transformer": 8, "streetlight": 12,
        "crossarm": None, "wire": None, "telcobox": None,
    },
    "utility_poles": {
        "concrete pole": 5, "concrete_pole": 5,
        "steel pole": 5, "wood pole": 5,
        "transformer": 8,
        "street light": 12, "streetlight": 12,
        "single crossarm": None, "double crossarm": None,
        "lightning arrester": None, "cutout": None,
        "splice case": None, "insulator": None,
    },
    "all_image": {
        "electricpole": 5, "electric pole": 5, "ElectricPole": 5,
        "transformer": 8, "Transformer": 8,
    },
    "cable_detection": {},
}
